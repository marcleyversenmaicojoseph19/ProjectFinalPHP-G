<?php
    session_start();
    
?>  

<?php 

    // declaration  du tableau de stockage des variables
    $tirageEquipe= array(
            "Bresil",
            "Argentine",
            "France",
            "Italie",
            "Espagne",
            "Allemagne",
            "Portugal",
            "Haiti"); 
    //  variable de stockage des groupes apres le tirage
    $gA;
    $gB;

    if(isset($_POST['tirageEquipe'])){

    //     ceci c'est pour indiquer qu'on a fait le tirage


    $incre=0;
    $aj=0;
    for($i=0;$i<4;$i++){
        $index1=rand(0,1);
        $index1=$index1+ $aj;


        if($index1 %2== 0){
                $_SESSION['gA'][$incre]=$tirageEquipe[$index1];
                $_SESSION['gB'][$incre]=$tirageEquipe[$index1+1];
                $incre++;
            }
        else{
                $_SESSION['gA'][$incre]=$tirageEquipe[$index1];
                $_SESSION['gB'][$incre]=$tirageEquipe[$index1-1]; 
                $incre++;
            }
            $aj=$aj+2;
        }
         
    }
//initialisation automatique du tableau des classements
    for($i=0; $i<4; $i++){
        $_SESSION['gA'][$i] = [$_SESSION['gA'][$i],0,0,0,0,0,0,0,0];
    }
    for($i=0; $i<4; $i++){
        $_SESSION['gB'][$i] = [$_SESSION['gB'][$i],0,0,0,0,0,0,0,0];
    }
    header('Location: tirage.php');
?>


