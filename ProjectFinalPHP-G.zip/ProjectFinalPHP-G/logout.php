<?php
  // Initialiser la session
  session_start();
  
  // Détruire la session.
  if(session_destroy())
  {

      //  detruire les sessions existantes  
      //table groupe A 
        unset($_SESSION['match1']);
        unset($_SESSION['match2']);
        unset($_SESSION['match3']);
        unset($_SESSION['match4']);
        unset($_SESSION['match5']);
        unset($_SESSION['match6']);
             //fin groupeA
           //table groupe B
        unset($_SESSION['match7']);
        unset($_SESSION['match8']);
        unset($_SESSION['match9']);
        unset($_SESSION['match10']);
        unset($_SESSION['match11']);
        unset($_SESSION['match12']);
               //table demie finale
        unset($_SESSION['matches1']);
        unset($_SESSION['matches2']);
             //table finale
        unset($_SESSION['matches3']);
        //table petite finale
        unset($_SESSION['matches4']);

    // Redirection vers la page de connexion
    header("Location: index.php");
  }
?>