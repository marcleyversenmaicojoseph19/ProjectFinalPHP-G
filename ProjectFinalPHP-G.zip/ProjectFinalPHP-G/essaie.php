<!-- echo "</table>";
 echo "<table border=0 cellpadding=0 cellspacing=0 class=bordure1><tr><td>";
 echo "<table cellspacing=1 cellpadding=2 border=0 width=100%>";
 echo "<tr>";
 echo "<td class=headerliste width=200>{$strTournois}</td>";
 echo "<td class=headerliste>{$strType}</td>";
 echo "<td class=headerliste>{$strJeu}</td>";
 echo "<td class=headerliste>{$strAdmins}</td>";
 echo "<td class=headerliste>{$strInscrits}</td>";
 echo "<td class=headerliste width=1%>{$strStatus}</td>";
 echo "</tr>";
 while ($tournois = $db->fetch($res)) {
     echo "<tr>";
     echo "<form>";
     echo "<input type=hidden name=id value={$tournois->id}>";
     echo "<td class=textliste><div style=\"clear: both\"><div style=\"float: left\">" . show_tournois($tournois->id) . '</div>';
     if ($op == 'admin' && (admin_tournois($s_joueur, $tournois->id) || $grade['a'] == 'a' || $grade['b'] == 'b')) {
         echo "<div style=\"float: right;\"><a href=?page=tournois&op=modify&id={$tournois->id}>[{$strE}]</a>";
         if ($tournois->status == "T") {
             echo "&nbsp;<a href=?page=tournois&op=delete&id={$tournois->id} onclick=\"return confirm('{$strConfirmEffacerTournois}');\">[{$strS}]</a>";
         }
         echo "</div>";
     }
     echo "</div></td>";
     if ($tournois->type == "T") {
         echo "<td class=textliste align=center>{$strTournois}</td>";
     }
     if ($tournois->type == "C") {
         echo "<td class=textliste align=center>{$strChampionnat}</td>";
     }
     if ($tournois->type == "E") { -->


<!-- EXAMPLE #20
File: block_admin_tournois.php Project: Arnaud-Burn/phpTournois
   | Authors: Li0n  <li0n@phptournois.net>                               |
   |          RV <rv@phptournois.net>                                    |
   |          Gougou                                                     |
   +---------------------------------------------------------------------+
*/ -->

<!-- if (eregi("block_admin_tournois.php", $_SERVER['PHP_SELF'])) {
    die("You cannot open this page directly");
} -->

<!-- HTML EDITED -->
<?php
global $config, $s_joueur, $s_theme, $s_tournois, $nom_tournois, $status_tournois, $type_tournois, $db, $dbprefix;
global $strAdmin, $strInscriptions, $strCloturerInscriptions, $strInscriptions, $strPoules, $strValiderPoules, $strMatchsPoules, $strTerminerPoules, $strTerminerTournois, $strHoraires, $strMaps, $strServeurs, $strFinales, $strValiderFinales, $strMatchsFinales, $strMatchsActifs, $strMatchsEnCours, $strAdminTournois;
global $strCloturerLesInscriptions, $strValiderLesPoules, $strTerminerLesPoules, $strValiderLesFinales, $strTerminerLeTournois, $grade;
?>
<?php
if (($grade['a'] == 'a' || $grade['b'] == 'b' || $grade['t'] == 't' || admin_tournois($s_joueur, $s_tournois)) && $status_tournois != 'T' && $s_tournois) 
        {
         theme_openblock("<img src=\"themes/{$s_theme}/images/icon_admintournois.gif\" align=\"absmiddle\" alt=\"admin\"> {$strAdmin}");
                  echo '<a href="?page=tournois&amp;op=modify&amp;id=' . $s_tournois . '">';
                  echo show_tournois($s_tournois, 1) . "</a><br />";
                  echo "<ul><li class=\"lib\"><a href=\"?page=inscriptions&amp;op=admin\">{$strInscriptions}</a><br />";
                      if ($status_tournois == "I") {
                           echo "<br /><li class=\"lir\"><a href=\"javascript:cloturer_inscriptions('{$strCloturerLesInscriptions}')\">{$strCloturerInscriptions}</a><br />";
                     }
                      elseif ($status_tournois == "G") {
                         echo "<li class=\"lib\"><a href=\"?page=poules&amp;op=admin\">{$strPoules}</a><br />";
                         echo "<br /><li class=\"lir\"><a href=\"javascript:valider_poules('{$strValiderLesPoules}')\">{$strValiderPoules}</a><br />";
                     } 
                     elseif ($status_tournois == "P") {
                         echo "<li class=\"lib\"><a href=\"?page=matchs_poules&amp;op=admin\">{$strMatchsPoules}</a><br />";
                         echo "<li class=\"lib\"><a href=\"?page=matchs_liste&amp;op=admin&amp;status=A\">{$strMatchsActifs}</a><br />";
                         echo "<li class=\"lib\"><a href=\"?page=matchs_liste&amp;op=admin&amp;status=D\">{$strMatchsEnCours}</a><br />";
                     if ($type_tournois == 'T') {
                         echo "<br /><li class=\"lir\"><a href=\"javascript:terminer_poules('{$strTerminerLesPoules}')\">{$strTerminerPoules}</a><br />";
                     } 
                     else {
                         echo "<br /><li class=\"lir\"><a href=\"javascript:terminer_tournois('{$strTerminerLeTournois}')\">{$strTerminerTournois}</a><br />";
        }

?>